#pragma once
#include <conio.h>
#include <cstdio>
#include <iostream>
#include <string>
#include <cstdlib>
#include<vector>
#define _CRT_SECURE_NO_WARNINGS
#pragma warning(disable:4996)
using namespace std;

class Bus
{
private:
	float Price;
	string Departure;
	string From;
	string To;
	int seat_max;
	int Row , Col;
	vector<vector<string>>Seats;
	string Driver;
	string Voucher;
public:
	int Number;
	void SetSeats();
	void Install();
	void Reverse();
	void Show();
	void ShowSeat();
	bool CheckEmpty(int No);
	void NameRev(string name, int Seat);
	Bus();
};

//Class cac loai xe dac biet 
class Bed_Car :public Bus 
{
public:
	void Luggage();
};

class VIP : public Bus
{
public:
public:
	void Luxury_Lounge();//Phong cho hang sang
	void Install();
};

class SuperVip : public Bus//Xe rieng tai xe rieng
{
	void Rent();//Thue xe va tai xe
	
};