#include"Bus_Khoa.h"

Bus::Bus()//Default Constructor for Demo
{
	Number = 1;
	Driver = "Khoa";
	Departure = "10:30";
	From = "HCM";
	To = "Ha Noi";
	Price = 10;
	Col = 5;
	Row = 8;
	seat_max = Row * Col;
	SetSeats();
}



void Bus::SetSeats()
{	
	Seats.resize(Row);
	for (int i = 0; i < Row; i++)
		Seats[i].resize(Col);

	for (int i = 0; i < Row; i++)
		for (int j = 0; j < Col; j++)
		{
			Seats[i][j] = "Empty";
		}
}


void Bus::Install()// FOR ADMIN ONLY 
{
	cout << "Bus No: ";
	cin >> Number;
	cin.ignore();
	cout << "Enter driver name: ";
	getline(cin, Driver);
	cout << "Enter Departure time: ";
	getline(cin, Departure);
	cout << "Going From: ";
	getline(cin, From);
	cout << "To: ";
	getline(cin, To);
	
	cout << "Enter Price: ";
	cin >> Price;
	cin.ignore();

	cout << "Enter Seat Rows and Cols: ";
	cin >> Row >> Col;
	cin.ignore();
	SetSeats();
	seat_max = Row * Col;

	cout << "Enter Discount Voucher code: ";
	getline(cin, Voucher);


}

void Bus::ShowSeat()
{
	int No = 1;
	for (int i = 0; i < Row; i++)
	{
		for (int j = 0; j < Col; j++)
		{
			cout << No << ". " << Seats[i][j] << "\t \t";
			No++;
		}	
		cout << endl;
	}
}

void Bus::Show()// Show for Customer
{
	cout << "Bus No: " << Number << endl;
	cout << "Driver: " << Driver << endl;
	cout << "Going From " << From << " To " << To << endl;
	cout << "Departure time: " << Departure << endl;
	cout << "Seat Available: " << seat_max << endl;
	cout << "Price per ticket: " << Price << endl;
}

bool Bus::CheckEmpty(int Seat)
{
	int Num = 1;
	for (int i = 0; i < Row; i++)
	{
		for (int j = 0; j < Col; j++)
		{
			if (Num == Seat)
				if (Seats[i][j] == "Empty")
					return true;
				else return false;
			Num++;
		}
	}
	return false;
}

void Bus::NameRev(string Name, int Seat)
{
	int Num = 1;
	for (int i = 0; i < Row; i++)
	{
		for (int j = 0; j < Col; j++)
		{
			if (Num == Seat)
				Seats[i][j] = Name;
			Num++;
		}
	}
}

void Bus:: Reverse()// For Customer
{
	int Seat_no, passenger, num_of_people;
	string Name, customer_Voucher;
	cout << "How many people: ";
	cin >> num_of_people;
	cin.ignore();
	for (int i = 0; i < num_of_people; i++)
	{
		cout << "Enter name: ";
		getline(cin, Name);
	top:
		cout << "Seat you want to Reverse: ";
		cin >> Seat_no;
		cin.ignore();

		if (Seat_no > seat_max)
		{
			cout << "There are only " << seat_max << " in this bus" << endl;

			system("pause");
			goto top;
		}

		if (CheckEmpty(Seat_no))
		{
			NameRev(Name, Seat_no);
			seat_max--;
		}
		else
		{
			cout << "This seat is already reverse." << endl;
			goto top;
		}
	}

	cout << "Enter Voucher(type no if you dont have): ";
	getline(cin, customer_Voucher);
	if (customer_Voucher == Voucher)
		cout << "You have 50% discount" << endl << "Bill:	" << (Price * num_of_people) * 0.5 << endl;
	else
		cout << "Bill: " << Price * num_of_people << endl;
}

int main()
{
	vector<Bus> a;
	char k;
	int bus;
	cout << "ADMIN SETUP" << endl;
	cout << "Enter buses you want to Install: ";
	cin >> bus;
	cin.ignore();
	for (int i = 0; i < bus; i++)
	{
		Bus b;
		b.Install();
		a.push_back(b);
		system("cls");
	}

	cout << endl;
	system("pause");
	system("cls");

	int Bus_No;

	cout << "CUSTOMER: " << endl;
	cout << "Buses availabile: " << endl;
	for (int i = 0; i < a.size(); i++)
	{
		a[i].Show();
		cout << endl;
	}
	cout << endl;
	cout << "Enter Bus No: ";
	cin >> Bus_No;

	for (int i = 0; i < bus; i++)
	{
		if (a[i].Number == Bus_No)
		{
			a[i].ShowSeat();
			a[i].Reverse();
			system("pause");
			system("cls");
			a[i].ShowSeat();
			break;
		}
	}

}