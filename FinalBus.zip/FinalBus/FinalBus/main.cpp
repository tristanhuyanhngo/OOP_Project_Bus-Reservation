#include"Bus.h"




int main()
{
	int count = 0;
	//ResizeConsole(900, 700);
	FixConsoleWindow();
	BusStation a;
	a.AdminMenu();
	system("pause");
}